﻿using System;
namespace godisAutomat
{
    public class Pepsi : Info, Interface
    {
        public Pepsi()
        {
            name = "Pepsi";
            price = "15kr";
            description = "En cola med en bra balans mellan söta och syrliga toner, precis som cola ska smaka.";
        }

        public void Buy()
        {
            Console.WriteLine("Du köpte en: " + name + " " + "för " + price);
        }

        public void Description()
        {
            Console.WriteLine("---Produktbeskrivning---");
            Console.WriteLine("En cola med en bra balans mellan söta och syrliga toner, precis som cola ska smaka.");
            Console.WriteLine("------------------------");
        }

        public void Use()
        {
            Console.WriteLine("Du dricker en Pepsi, och undrar varför maskinen inte hade vanlig Cola.");
        }
    }
}

