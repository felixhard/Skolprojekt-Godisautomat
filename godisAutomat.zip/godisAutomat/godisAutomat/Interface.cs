﻿using System;
namespace godisAutomat
{
    public interface Interface
    {
        public void Description();

        public void Buy();

        public void Use();
     
      
    }
}

