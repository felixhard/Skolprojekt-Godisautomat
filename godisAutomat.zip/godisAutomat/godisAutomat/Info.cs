﻿using System;
namespace godisAutomat
{
    public abstract class Info
    {
        public string name;
        public string price;
        public string description;
        
    }
}

