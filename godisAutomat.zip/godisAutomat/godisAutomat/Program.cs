﻿namespace godisAutomat
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            ConsoleKeyInfo input;

            do
            {
                //Rensa konsollen
                Console.Clear();
                //Skriv ut meny
                Console.WriteLine("Välkommen till Godisautomaten");
                Console.WriteLine("-----------------------------");
                Console.WriteLine("1. Visa produkter");
                Console.WriteLine("2. Avsluta");
                Console.WriteLine("-----------------------------");

                //Hämta användarens menyval
                input = Console.ReadKey();

                //SwitchCase
                switch (input.KeyChar.ToString())
                {
                    case "1":
                        Console.Clear();
                        productSelectionMenu();

                        break;
                    default:
                        //Hantering vid fel val
                        break;

                }

            } while (input.KeyChar.ToString() != "2");
        }
        
        
        public static void productSelectionMenu()
        {
            RedBull redbull = new RedBull();
            Twix twix = new Twix();
            Pepsi pepsi = new Pepsi();
            string input2;

            Console.WriteLine("------UTBUD------");
            Console.WriteLine("-----------------");
            Console.WriteLine("1. Redbull: 20kr");
            Console.WriteLine("2. Twix: 10kr");
            Console.WriteLine("3. Pepsi: 15kr");
            Console.WriteLine("4. Gå tillbaka");
            Console.WriteLine("-----------------");
            Console.WriteLine("Klicka på enter när du gjort ditt val.");
            Console.WriteLine("--------------------------------------");
            
            input2 = Console.ReadLine();
            if (input2 == "1")
            {  
                Console.Clear();
                redbull.Description();
                ConsoleKeyInfo input3;
                do
                {
                    Console.WriteLine("Är du säker på att du vill köpa en RedBull för 20kr?");
                    Console.WriteLine("1. Ja, jag är säker.");
                    Console.WriteLine("2. Nej, gå tillbaka.");
                    input3 = Console.ReadKey();
                    switch (input3.KeyChar.ToString())
                    {
                        case "1":
                            Console.Clear();
                            redbull.Buy();
                            redbull.Use();
                            
                            break;
                        default:
                            break;
                    }
                } while (input3.KeyChar.ToString() != "2");
                    
            }else if(input2 == "2")
            {
                Console.Clear();
                twix.Description();
                ConsoleKeyInfo input4;
                do
                {
                    Console.WriteLine("Är du säker på att du vill köpa en Twix för 10kr?");
                    Console.WriteLine("1. Ja, jag är säker.");
                    Console.WriteLine("2. Nej, gå tillbaka.");
                    input4 = Console.ReadKey();
                    switch (input4.KeyChar.ToString())
                    {
                        case "1":
                            Console.Clear();
                            twix.Buy();
                            twix.Use();
                            break;
                        default:
                            break;
                    }
                } while (input4.KeyChar.ToString() != "2");
            }else if(input2 == "3")
            {
                Console.Clear();
                pepsi.Description();
                ConsoleKeyInfo input5;
                do
                {
                    Console.WriteLine("Är du säker på att du vill köpa en Pepsi för 15kr?");
                    Console.WriteLine("1. Ja, jag är säker.");
                    Console.WriteLine("2. Nej, gå tillbaka.");
                    input5 = Console.ReadKey();
                    switch (input5.KeyChar.ToString())
                    {
                        case "1":
                            Console.Clear();
                            pepsi.Buy();
                            pepsi.Use();
                            break;
                        default:
                            
                            break;
                    }
                } while (input5.KeyChar.ToString() != "2");
        
            }

            
        }
        
        
    }
}

