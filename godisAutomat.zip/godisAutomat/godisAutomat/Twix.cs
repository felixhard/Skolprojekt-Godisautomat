﻿using System;
namespace godisAutomat
{
    public class Twix : Info, Interface
    {
        public Twix()
        {
            name = "Twix";
            price = "10kr";
            description = "En chokladpralin med ett krispigt kex samt en mjuk och seg kola.";
        }

        public void Buy()
        {
            Console.WriteLine("Du köpte en: " + name + " " + "för " + price);
        }

        public void Description()
        {
            Console.WriteLine("---Produktbeskrivning---");
            Console.WriteLine(description);
            Console.WriteLine("------------------------");
        }

        public void Use()
        {
            Console.WriteLine("Du äter en Twix.");
        }
    }
}

