﻿using System;
namespace godisAutomat
{
    public class RedBull : Info, Interface
    {
        public RedBull()
        {
            name = "RedBull";
            price = "20kr";
            description = "Ger dig vingar";
        }

        public void Buy()
        {
            Console.WriteLine("Du köpte en: " + name + " " + "för " + price);
        }

        public void Description()
        {
            Console.WriteLine("---Produktbeskrivning---");
            Console.WriteLine(description);
            Console.WriteLine("------------------------");
        }

        public void Use()
        {
            Console.WriteLine("Du dricker RedBull och känner att fötterna lyfter från marken");
        }
    }
}

