﻿using System;
namespace godisAutomat
{
    public class Wallet
    {
        public Wallet()
        {

        }
    }
}

